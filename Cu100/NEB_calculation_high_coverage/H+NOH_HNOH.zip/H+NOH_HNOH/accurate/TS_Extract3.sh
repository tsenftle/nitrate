#!/bin/sh

# extracts energy from a TS calculation

### Saves result in $str
MakeDirListString()
{
    if [ $# -ne 1 ] ; then
        echo "Error in MakeDirListString()"
        exit 1
    fi
    
    str=""
    oldname=""
    name=""
    
    ## start past the first one    
    loop=1
    while [ $loop -lt 100 ] ; do
        if [ $loop -lt 10 ] ; then
            name=$1/0$loop
        else
            name=$1/$loop
        fi
        
        if [ -d $name ] ; then
            str="$str $oldname"
            oldname=$name
        else
            break
        fi
        
        loop=`expr $loop + 1`
    done
}


if [ -d WorkDir/01 ] ; then
    FileBase="WorkDir"
elif [ -d 01 ] ; then
    FileBase="."
else
    echo "Error: could not find directory WorkDir/01 or /01"
    exit 2
fi

MakeDirListString $FileBase


echo ""
len=`grep " F= " ./01/OSZICAR -c`
echo "Energies of $str - Iteration $len"
echo ""
echo -e "Energy \t\t E - E0 \t F Tangent \t F Spring \t F Normal \t F Max"
echo ""
E0=`grep EFIRST INCAR |awk '{print $3}'`
printf "%f \n" $E0
hold=`grep "NEB: projections on to tangent" 01/OUTCAR | tail -n 1 | awk '{print $1}'`

## VASP 4
if [ "$hold" == "NEB:" ]; then
for i in $str ; do
    Ei=`grep "energy  without entropy" $i/OUTCAR |tail -n 1 |awk -F = '{print $3}' |awk '{print $1}'`
    dE=`echo "$Ei - $E0" | bc`
    Ftan=`grep "NEB: projections on to tangent" $i/OUTCAR | tail -n 1 | awk '{print $9}'`
    Fspr=`grep "NEB: projections on to tangent" $i/OUTCAR | tail -n 1 | awk '{print $8}'`
    Fnorm=`grep "NEB: forces: par spring" $i/OUTCAR | tail -n 1 | awk '{print $9}'`
    Fmax=`grep "FORCES: max atom" $i/OUTCAR | tail -n 1 | awk '{print $5}'`
    printf "%f \t %f \t %f \t %f \t %f \t %f \n" $Ei $dE $Ftan $Fspr $Fnorm $Fmax
done

## VASP 5
else
for i in $str ; do
    Ei=`grep "energy  without entropy" $i/OUTCAR |tail -n 1 |awk -F = '{print $3}' |awk '{print $1}'`
    dE=`echo "$Ei - $E0" | bc`
    Ftan=`grep "tangential force" $i/OUTCAR | tail -n 1 | awk '{print $4}'`
    Fspr=`grep "NEB: projections on to tangent" $i/OUTCAR | tail -n 1 | awk '{print $8}'`
    Fnorm=`grep "NEB: forces: par spring" $i/OUTCAR | tail -n 1 | awk '{print $9}'`
    Fmax=`grep "FORCES: max atom" $i/OUTCAR | tail -n 1 | awk '{print $5}'`
    printf "%f \t %f \t %f \t %f \t %f \t %f \n" $Ei $dE $Ftan $Fspr $Fnorm $Fmax
done
fi

Ei=`grep ELAST INCAR |awk '{print $3}'`
dE=`echo "$Ei - $E0" | bc`
printf "%f \t %f \n" $Ei $dE
echo ""
echo -e "Previous \t Next \t\t Angle \t\t k Previous \t k Next \n"
for i in $str ; do
    prev=`grep "NEB: distance to prev" $i/OUTCAR | tail -n 1 | awk '{print $9}'`
    next=`grep "NEB: distance to prev" $i/OUTCAR | tail -n 1 | awk '{print $10}'`
    angle=`grep "NEB: distance to prev" $i/OUTCAR | tail -n 1 | awk '{print $11}'`
    kprev=`grep "NEB: spring constants" $i/OUTCAR | tail -n 1 | awk '{print $5}'`
    knext=`grep "NEB: spring constants" $i/OUTCAR | tail -n 1 | awk '{print $6}'`
    printf "%f \t %f \t %f \t %f \t %f \n" $prev $next $angle $kprev $knext
done
echo ""
a=`grep "energy  without entropy" 01/OUTCAR |tail -1 |awk '{print $7}'`
a=`echo $a \\* 1000000 | bc | awk '{printf "%.0f\n", $1}'`
image=01
for i in $str ; do
   b=`grep "energy  without entropy" $i/OUTCAR |tail -1 |awk '{print $7}'`
   b=`echo $b \\* 1000000 | bc | awk '{printf "%.0f\n", $1}'`
   if [ $b -gt $a ]; then
       image=$i
       a=$b
   fi
done
echo "$image is climbing"

echo -e "\nI \t E - E0 \t F Tangent \t F Spring \t F Normal \t F Max \n"

# VASP 4
if [ "$hold" == "NEB:" ]; then
    for i in `seq 1 $len`; do
        E=`grep "energy  without entropy" $image/OUTCAR | head -n $i | tail -n 1 | awk -F = '{print $3}' | awk '{print $1}'`
        dE=`echo "$E - $E0" | bc`
        Ftan=`grep "NEB: projections on to tangent" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $9}'`
        Fspr=`grep "NEB: projections on to tangent" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $8}'`
        Fnorm=`grep "NEB: forces: par spring" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $9}'`
        Fmax=`grep "FORCES: max atom" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $5}'`
        printf "%d \t %f \t %f \t %f \t %f \t %f \n" $i $dE $Ftan $Fspr $Fnorm $Fmax
    done

## VASP 5
else
    for i in `seq 1 $len`; do
        E=`grep "energy  without entropy" $image/OUTCAR | head -n $i | tail -n 1 | awk -F = '{print $3}' | awk '{print $1}'`
        dE=`echo "$E - $E0" | bc`
        Ftan=`grep "tangential force" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $4}'`
        Fspr=`grep "NEB: projections on to tangent" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $8}'`
        Fnorm=`grep "NEB: forces: par spring" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $9}'`
        Fmax=`grep "FORCES: max atom" $image/OUTCAR | head -n $i | tail -n 1 | awk '{print $5}'`
        printf "%d \t %f \t %f \t %f \t %f \t %f \t" $i $dE $Ftan $Fspr $Fnorm $Fmax
    done
fi

echo -e "\nI \t E - E0 \t F Tangent \t F Spring \t F Normal \t F Max \n"
